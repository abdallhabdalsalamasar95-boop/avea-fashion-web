'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"ads.txt": "58997043f02dc5a9aec5588eb85ff580",
"adsense-config.js": "a304d49571e8b1a9ded50c75e714a913",
"assets/AssetManifest.bin": "1a792e752af6a63a81a703d7db5bef0b",
"assets/AssetManifest.bin.json": "604dc0078dd7e8a789b933e5c6cc08c6",
"assets/assets/avea_icon.jpeg": "69c7874b37bc92533b6fb3b031d8a1e0",
"assets/assets/categories/best_sellers.webp": "f8b986cae9c4e765e1aad1b5c99d7b31",
"assets/assets/categories/eid.webp": "8dd5a5db9ff44583058ece072cc1a1a9",
"assets/assets/categories/evening.webp": "ec509b90678fd783a64d8c12d7fcc1c4",
"assets/assets/categories/jumpsuit.webp": "91cce9696d4ff4b8c7089731ed79cb38",
"assets/assets/categories/mature.webp": "8ca75c9d03c426c1d98f455299aeaca6",
"assets/assets/categories/ramadan.webp": "747d8c6dd53fdff4596b4160b625f36f",
"assets/assets/categories/sale.webp": "3bbfe87485392cb8f81d66fe22c19ddb",
"assets/assets/categories/soft.webp": "a86464e90ad770d728d014290f94f279",
"assets/assets/logo.svg": "847613c54615d5c6e3b6006ba1b6e994",
"assets/assets/products/dress_01.svg": "21e44af166bac29f22979dec6748726e",
"assets/assets/products/dress_02.svg": "5df09cbd2290bb0969e220a336b325cd",
"assets/assets/products/dress_03.svg": "d680f5f5f64464e35a6e518656faab95",
"assets/assets/products/dress_04.svg": "8d6e316ba7da7ea0c566c5e403085ac0",
"assets/assets/products/dress_05.svg": "5b2f9fd127585fd6a306c86756d5beaf",
"assets/assets/products/dress_06.svg": "ca786815fc83ce366855ec265379bde3",
"assets/FontManifest.json": "dc3d03800ccca4601324923c0b1d6d57",
"assets/fonts/MaterialIcons-Regular.otf": "fdb1aaaa509151a2174ac629f20d5b62",
"assets/NOTICES": "e9dbaae8ce05cceae0e52ba5eb141776",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "33b7d9392238c04c131b6ce224e13711",
"assets/PRIVACY_POLICY.md": "c4188b9374bd87d48ccb53f3237ef5f1",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/shaders/stretch_effect.frag": "40d68efbbf360632f614c731219e95f0",
"assets/TERMS_OF_SERVICE.md": "1361d21f0cfd5c01deeac33e29c2f86b",
"canvaskit/canvaskit.js": "8331fe38e66b3a898c4f37648aaf7ee2",
"canvaskit/canvaskit.js.symbols": "a3c9f77715b642d0437d9c275caba91e",
"canvaskit/canvaskit.wasm": "9b6a7830bf26959b200594729d73538e",
"canvaskit/chromium/canvaskit.js": "a80c765aaa8af8645c9fb1aae53f9abf",
"canvaskit/chromium/canvaskit.js.symbols": "e2d09f0e434bc118bf67dae526737d07",
"canvaskit/chromium/canvaskit.wasm": "a726e3f75a84fcdf495a15817c63a35d",
"canvaskit/skwasm.js": "8060d46e9a4901ca9991edd3a26be4f0",
"canvaskit/skwasm.js.symbols": "3a4aadf4e8141f284bd524976b1d6bdc",
"canvaskit/skwasm.wasm": "7e5f3afdd3b0747a1fd4517cea239898",
"canvaskit/skwasm_heavy.js": "740d43a6b8240ef9e23eed8c48840da4",
"canvaskit/skwasm_heavy.js.symbols": "0755b4fb399918388d71b59ad390b055",
"canvaskit/skwasm_heavy.wasm": "b0be7910760d205ea4e011458df6ee01",
"fallback.html": "6f0c3c16e567c45799e0a9966c1d55fb",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"flutter.js": "24bc71911b75b5f8135c949e27a2984e",
"flutter_bootstrap.js": "b0dfadfad1098ee4e9ec6bd6c4f9176f",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"index.html": "d6091c573125db262b03f1e0723e7e7c",
"/": "d6091c573125db262b03f1e0723e7e7c",
"main.dart.js": "fa2ed412fe83b5dc7ea82e1e0b6a04c7",
"manifest.json": "08ca62939ba1cb022edb1a538117c926",
"order.html": "587cf867032ed4b6588ad1e44f06c36c",
"products.html": "2ce17233aff61c5ccd44354095b536af",
"splash/img/dark-1x.png": "66bd59ecbb65682b6ea93a5218700621",
"splash/img/dark-2x.png": "8f5d095cfa1aa9b956d6f1db23705590",
"splash/img/dark-3x.png": "8902f0280f48c882dead11710c24b2a8",
"splash/img/dark-4x.png": "b1a819fe484cf53ca67dbe6f6aac8e5b",
"splash/img/light-1x.png": "66bd59ecbb65682b6ea93a5218700621",
"splash/img/light-2x.png": "8f5d095cfa1aa9b956d6f1db23705590",
"splash/img/light-3x.png": "8902f0280f48c882dead11710c24b2a8",
"splash/img/light-4x.png": "b1a819fe484cf53ca67dbe6f6aac8e5b",
"sqflite_sw.js": "d8a4c299760257897c4fd1693e958abe",
"sqflite_sw.js.deps": "b71fc29249a4c7c8458cc686c6df696e",
"sqflite_sw.js.map": "7ccb3405560f6abbc9a7220f92685a19",
"sqlite3.wasm": "a4fe605c530a5e5dfd4819303dc75829",
"style.css": "d49f3a1f8630f15e91ab5006d69f8795",
"version.json": "0f2ada072dbcb5f769b72023c2cf41cb"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
